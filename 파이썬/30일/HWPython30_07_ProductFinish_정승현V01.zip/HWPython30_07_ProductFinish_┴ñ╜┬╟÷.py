import re
productFile = open('./_dataset01/product.csv','r', encoding='utf8')
productList = productFile.readlines()
a = []
b = []
for x in range(len(productList)):
	if x == 0:
		pass
	elif x >= 1:
		a.append(productList[x])

def productChk(a):
	for y in range(len(a)):
		aList=a[y].split(',')
		if 'Chair' in a[y]:
			aList.insert(-1, '의자')
			b.append(aList)
		elif 'Mirror' in a[y]:
			aList.insert(-1, '거울')
			b.append(aList)
		elif 'Table' in a[y]:
			aList.insert(-1, '테이블')
			b.append(aList)
		elif 'Sofa' in a[y]:
			aList.insert(-1, '소파')
			b.append(aList)
		else:
			aList.insert(-1,'품목 미체크 확인')
			b.append(aList)

productChk(a)
for x in b:
	print(x)














			








