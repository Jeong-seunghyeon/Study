file = open('./_dataset01/product.csv','r')
f = file.readlines()
print(f)

