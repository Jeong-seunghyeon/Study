#Modul_5.py

from Modul_1 import*
print(sum(3,4))

print(__name__)
