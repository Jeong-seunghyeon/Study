#Modul_4.py

import Modul_1 as m1

print(m1.sum(3,4))
print(m1.safe_sum(3,6))
