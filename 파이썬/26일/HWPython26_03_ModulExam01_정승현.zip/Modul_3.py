#Modul_3.py

from Modul_1 import sum,safe_sum

print(sum(3,4))
print(safe_sum(3,5))

