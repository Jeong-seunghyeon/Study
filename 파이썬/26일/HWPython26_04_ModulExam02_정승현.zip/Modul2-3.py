#Modul2-3

from Modul2_2 import*
print(sum(3,4))