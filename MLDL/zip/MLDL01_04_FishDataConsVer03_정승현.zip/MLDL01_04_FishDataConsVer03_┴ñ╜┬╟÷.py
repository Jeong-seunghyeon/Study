import pandas as pd

class FishData:
    def __init__(self, file='./_DataSetMLDL/Fish.csv'):
        self.fishObj = pd.read_csv(file)
        self.alldata = self.fishObj.values
        self.header = self.fishObj.columns
        self.fishSpecies = self.fishObj['Species'].unique()
  


    


if __name__ =='__main__':
    fish01 = FishData(file='./_DataSetMLDL/Fish.csv')
    print(fish01.header)
    print(fish01.alldata.shape)
    print(fish01.alldata[:3])
    print(fish01.fishSpecies)





