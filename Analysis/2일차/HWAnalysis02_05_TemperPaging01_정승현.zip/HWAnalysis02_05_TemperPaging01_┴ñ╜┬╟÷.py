import csv
f = open('./_dataSetGilBut01/daejeon.csv','r', encoding='949')
data = csv.reader(f,delimiter=',')
data1 = list(data)
vdata=[]
b = 1


print('총 데이터 수는',len(data1),'개 입니다.')
dataPerPage = int(input('페이지당 보여 줄 건수를 지정하세요. '))
totalPage = 0
if len(data1)%dataPerPage == 0:
	totalPage = (len(data1)//dataPerPage)
elif len(data1)%dataPerPage != 0:
	totalPage = ((len(data1)//dataPerPage)+1)
print('총 [',totalPage,'] 개 페이지 입니다.')

while True:
	a = input('확인할 페이지를 입력하세요. [ 0 : 종료 ] : ')
	
	if a == '':
		a = 0
	elif a == '0' :
		print('종료합니다.')
		exit()
	else:
		a = int(a)
	print(type(a))
	vdata=[]

	for x in range(0,len(data1)):
		if a == 0:
			if dataPerPage*(int(b)-1) <= x :
				vdata.append(data1[x])
				print(x,' / ',x+1,(len(vdata)-1), data1[x])

				if x >= dataPerPage*(int(b)):
					b += 1
					print(b)
					break
		elif int(a) > totalPage :
			print('확인할 수 있는 페이지 초과입니다.')
			break
		elif int(a) <= totalPage:
			if dataPerPage*(int(a)-1)<= x <dataPerPage*(int(a)):
				vdata.append(data1[x])
				print(x,' / ',x+1,(len(vdata)-1), data1[x])
				if x >= dataPerPage*(int(a)+1):
					break
	

