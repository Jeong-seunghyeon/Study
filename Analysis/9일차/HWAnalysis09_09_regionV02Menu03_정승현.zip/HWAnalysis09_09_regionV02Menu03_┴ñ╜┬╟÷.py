import csv
import matplotlib
import pandas as pd
import numpy as np

populationfile = []

siDoGuGunList = []

siDoList = []
soDoNoList = []

siDoNoUK = []   # UK 는 Unique
siDoUK = []

tempSidoNo = -1

regionMenu = []

menu = []

tempRegion = []
totalRecSu = []

sec02GuGunUK = []
sec02GuGunNoUK = []

sec03EupMyeonDong = [] 
sec03EupMyeonDongNo = []
populationRegionFileList = []

populRegionFileList = ['populationGenderSeoul.csv', 'populationGenderBusan.csv',
        'populationGenderDaegu.csv', 'populationGenderIncheon.csv', 
        'populationGenderGwangju.csv','populationGenderDaejeon.csv', 
        'populationGenderUlsan.csv', 'populationGenderSejong.csv',

        'populationGenderGyeonggi.csv', 'populationGenderGangwon.csv', 'populationGenderChungbuk.csv',
        'populationGenderChungnam.csv', 'populationGenderJeonbuk.csv', 'populationGenderJeonnam.csv',
        'populationGenderGyeongbuk.csv','populationGenderGyeongnam.csv','populationGenderJeju.csv'
        ]

tempRegion = []



#-----------------------------------------------------------------------------------------

file=open(f"_dataSetGilBut01\population202202Gender.csv","r",encoding="cp949")
file=csv.reader(file)

for row in file:
    populationfile.append(row)

# print(len(populationfile))

vData = np.array(populationfile)
print(len(populationfile))
print(vData.shape)
print(populationfile[0][103])
#print(len(populationfile[0]))


for x in populationfile:
    if tempSidoNo != (x[0][-11:-9]):
        if x[0][0] == '행':
            pass
        else:
            siDoUK.append(x[0][0:-14])
            siDoNoUK.append(x[0][-11:-9])
            tempSidoNo = x[0][-11:-9]
    elif tempSidoNo == (x[0][-11:-9]):
        pass
    
# print(siDoUK)
# print(siDoNoUK)

for y in range(len(siDoUK)):
    regionMenu.append(siDoUK[y]+":"+siDoNoUK[y][0:2])
    
    
for i in range(len(regionMenu)):
    vmenu=regionMenu[i].split(",")
    menu.append(vmenu)


#----------------------------------------------------------------------------------------

# for idx in range(len(populRegionFileList)):
#     dataSet = open(f'C:\_pythontest01\Analysis\_dataSetGilBut01\population202202.csv','r','cp949')
#     dataSet.close()

# for fileIdx in range(len(populRegionFileList)):
#     dataSet = open(f'_dataSetGilBut01/{populRegionFileList[fileIdx]}','w',newline='',encoding = "cp949")
#     dataSet.close()
    

def regionFileSet() :
    totalRecSu = []          
    tempSiDoNo    = -1
    populRegionFileIdx = 0
    while True:
        for x in range(len(populationfile)) :
            tempRegion = []
            vpop = populationfile[x][0].split()
            if vpop[0] == siDoUK[populRegionFileIdx] :
                if vpop[0] =='행정구역':
                    pass
                else:
                    tempRegion.append(populationfile[x])
                    dataSet = open(f'_dataSetGilBut01/{populRegionFileList[populRegionFileIdx]}','a',newline='',encoding = "cp949")
                    wr = csv.writer(dataSet)
                    wr.writerow(populationfile[x])
        populRegionFileIdx += 1
        if populRegionFileIdx == 17:
            break
        dataSet.close()
                

    for idx in range(len(populRegionFileList)):
        f = open(f'_dataSetGilBut01/{populRegionFileList[idx]}','r',encoding='cp949')
        vf = csv.reader(f)
        b = []
        for a in vf:
            b.append(a)
            c = (b[0][0].split())
        totalRecSu.append(c[0]+':'+str(len(b)))   


    
        

        
        
    for idx in range(len(populRegionFileList)):
        f = open(f'_dataSetGilBut01/{populRegionFileList[idx]}','r',encoding = "cp949" )
        
                

regionFileSet()
#------regionTitle--------------------------------------------
def regionTitle():
    print("{0:=^91}\n".format("인구 공공데이터 분석 프로젝트 Ver01. "))
    cnt = 0
    for idx in range(17):
        siDoNoUK[idx] = siDoNoUK[idx][:2]
        siDoLen = len(siDoUK[idx]) + (14 - (len(siDoUK[idx])*2))
        print(f"[{siDoUK[idx]:<{siDoLen}}:{siDoNoUK[idx]}]",end="")
        cnt +=1
        
        if cnt%4 == 0:
            print()
    print("\n")

    # print(menu[0:4])
    # print(menu[4:8])
    # print(menu[8:12])
    # print(menu[12:16])
    # print(menu[16:])
    # print('='*98)

#--subMenuTitle---------------------------------------
def subMenuTitle():
    city=""
    userInput=input("\t\t메뉴의 번호를 입력하세요 [Q: 메뉴종료]:")
    if userInput.upper()=="Q":
        exit()
    for idx in range(len(siDoNoUK)):
        print(siDoNoUK[idx])
        if userInput==siDoNoUK[idx]:
            idxChk=idx
            city=siDoUK[idxChk]
            print()
            print(f"\t\t^{siDoUK[idxChk]} 지역이 선택 되었습니다.")
            print()
            break
    else:
        print(f"{userInput} >> 해당 지역 없습니다.")
    return city


#subMenuChk-----------------------------------------------


def subMenuChk(city):
    
    if city in siDoUK:
        #print(siDoUK.index(city))
        idx=siDoUK.index(city)
        
        
        while True:
            print("-"*25, end="")
            print(f"{city}지역 데이터 개수", end="")
            print("-"*25)
            print()
            print("1. 데이터 확인  2. 현재지역확인  3.전체구간 확인  4. MenuChk  5.MenuChk 6.MenuChk")
            print("-"*77)
            print()
            userInput=input("서브메뉴 번호를 입력하세요 [Q: 서브메뉴 종료]:")
            if userInput == '1':
                regionPagingData(idx)
            elif userInput == '2':
                regionChk(idx)
            elif userInput == '3':
                regionDbSet(idx)
            elif userInput == '4':
                print('MenuChk 확인')
            elif userInput == '5':
                print('MenuChk 확인')
            elif userInput == '6':
                print('MenuChk 확인')
            elif userInput.upper() == 'Q':
                print('서브메뉴를 종료합니다.')
                break
            else:
                print('해당없음')

#gettotal-------------------------------------------
def getTotalPage(m, n):
	if m % n == 0:
		return m // n
	else:
		return m // n + 1
#페이징----------------------------------------------------------------------------------------------------------------------------
def regionPagingData(idx):
	file=open('./_dataSetGilBut01/'+populRegionFileList[idx],'r',encoding='cp949')
	regionData = csv.reader(file)
	vRegionData=list(regionData)
	

	dataPerPage=int(input("한 페이지당 출력할 레코드 수를 입력하세요:"))
	totalPage=getTotalPage(totalRecSu[idx], dataPerPage)


	print("-"*50)
	print(f"기온 공공데이터 개수{totalRecSu[idx]}")
	print(f"기온 공공데이터 페이지 개수: {totalPage}")
	print("-"*50)

	Page=0
	tempPage=1
	while True:
		print(f"Enter를 치면 다음 {tempPage}/{totalPage} 페이지 {dataPerPage}개 레코드 확인") 
		nowPage=input("확인할 페이지를 입력 또는 Enter[Q:종료]:")
		if nowPage.upper()=="Q":
			print("종료합니다.")
			break
		elif nowPage=="":
			tempPage+=1
			if tempPage==totalPage:
				print("마지막 페이지입니다.")
			else:
				for dataOfBeginPage in range(Page,(Page+dataPerPage)):
					print(f"{dataOfBeginPage}/{totalRecSu[idx]}  {dataOfBeginPage}번째 {vRegionData[dataOfBeginPage]}")
					Page+=1
				print("-"*50)
		else:
			dataOfBeginPage=(int(nowPage)-1)*dataPerPage
			for dataOfBeginPage in range((dataOfBeginPage),(dataOfBeginPage+dataPerPage)):
				if dataOfBeginPage > totalRecSu-1:
					print()
					print("확인할 수 있는 페이지 초과입니다")
					break
				else:
					print(f"{dataOfBeginPage}/{totalRecSu}  {dataOfBeginPage}번째 {vRegionData[dataOfBeginPage]}")
					tempPage=int(nowPage)


#현재지역확인---------------------------------------------------------------------------------------------------------------------
def regionChk(idx):
	print(f"	^{siDoUK[idx]} 지역이 선택 되었습니다.")
	print(f"{'-'*30} {siDoUK[idx]} 지역 데이터 개수 [{totalRecSu[idx]}] 확인 {'-'*30}")
	return
#전체구간확인---------------------------------------------------------------------------------------------------------------------
def regionDbSet(idx):
    global populationRegionFileList
    populationRegionFileList.clear()

    sec02GuGunUK.clear()
    sec02GuGunNoUK.clear()

    sec03EupMyeonDong.clear()
    sec03EupMyeonDongNo.clear()

    tempdo =""
    tempSec=[]
    secStartRow=[]
    tempguno = []
    tempeup =[]
    tempDongNo=[]
    sec02UkChk=-1

    file=open('./_dataSetGilBut01/'+populRegionFileList[idx],'r',encoding='cp949')
    regionData = csv.reader(file)
    populationRegionFileList=list(regionData)

    for i, regionlist in enumerate(populationRegionFileList):
        # print(i, regionlist[0])
        temp=regionlist[0].split()
        # print(temp)
        tempguno.append(temp[-1][-9:-7])
        sec03EupMyeonDongNo.append(temp[-1][-9:-1])
        if tempguno[i][:2] != tempdo:
            sec02UkChk+=1
            tempSec.append(1)
            sec02GuGunUK.append(temp[-2])
            tempdo=tempguno[i][:2]
            sec02GuGunNoUK.append(tempguno[i][:2])
            if sec02UkChk>0:
                sec03EupMyeonDong.append(tempeup)
                sec03EupMyeonDongNo.append(tempDongNo)
            tempeup=[]
            tempDongNo=[]
        else:
            tempSec[sec02UkChk]+=1
            tempeup.append(temp[-1][:-12])
            tempDongNo.append(temp[-1][-9:-1])
    sec03EupMyeonDong.append(tempeup)
    sec03EupMyeonDongNo.append(tempDongNo)
	# print(sec03EupMyeonDongNo)
	# print(sec03EupMyeonDong)
	# print(tempSec)
    for x in range(len(sec02GuGunUK)-1):
        if x==0:
            print()
            print(f"{sec02GuGunUK[0]}  {len(sec02GuGunNoUK)-1}개 구군 확인")
        else:
            print(f"[{sec02GuGunUK[x]} No : {sec02GuGunNoUK[x]}] >>> {len(sec03EupMyeonDong[x])}개 읍면동 ")
		# print()
        for y in range(len(sec03EupMyeonDong[x])):
            if y%5 == 0:
                print()
                print(sec03EupMyeonDong[x][y], end=" " )
            else:
                print(sec03EupMyeonDong[x][y], end=" " )
        print()
        print()
        print()
  
        print("Total_읍면동",":", sum(tempSec))

def regionSection02(idx):
    print(f'    >>> {siDoUK[idx]}No : {siDoNoUK[idx][0:2]} ] {len(sec02GuGunUK)-1}개 Section02 확인')
    for x in range(1,len(sec02GuGunUK)):
        print(f"{x}]{sec02GuGunUK[x]}")
    userInput = (input( '메뉴의 번호를 입력해 주세요. [ Q : 메뉴종료 ]: '))
    if userInput.upper() == 'Q':
        regionSection02(idx)
    elif int(userInput) > len(sec02GuGunUK):
        print('입력한 값을 확인하세요.')
    
    else:
        vuserInput = 1
        print(f"{int(userInput)}.{sec02GuGunUK[int(userInput)]} No.{sec02GuGunNoUK[int(userInput)]} {len(sec03EupMyeonDong[int(userInput)])}개 지역이 선택되었습니다.")
        for q in range(len(userInput)+len(sec03EupMyeonDong[int(vuserInput)])):
            if vuserInput <= int(userInput):
                print()
                print()
                print(f"{sec02GuGunUK[int(vuserInput)]} {sec03EupMyeonDong[int(vuserInput)]} / {len(sec03EupMyeonDong[int(vuserInput)])+1}")
                vuserInput += 1
            elif vuserInput == userInput:
                print(sec03EupMyeonDong.index(sec03EupMyeonDong[userInput][0]))
                break
                
while True:
    regionTitle()
    city = subMenuTitle()
    subMenuChk(city)
    