import csv
import matplotlib
import pandas as pd
import numpy as np

populationfile = []

siDoGuGunList = []

siDoList = []
soDoNoList = []

siDoNoUK = []   # UK 는 Unique
siDoUK = []

tempSidoNo = -1

regionMenu = []

menu = []

populRegionFileList = ['populationGenderSeoul.csv', 'populationGenderBusan.csv',
        'populationGenderDaegu.csv', 'populationGenderIncheon.csv', 
        'populationGenderGwangju.csv','populationGenderDaejeon.csv', 
        'populationGenderUlsan.csv', 'populationGenderSejong.csv',

        'populationGenderGyeonggi.csv', 'populationGenderGangwon.csv', 'populationGenderChungbuk.csv',
        'populationGenderChungnam.csv', 'populationGenderJeonbuk.csv', 'populationGenderJeonnam.csv',
        'populationGenderGyeongbuk.csv','populationGenderGyeongnam.csv','populationGenderJeju.csv'
        ]

tempRegion = []



#-----------------------------------------------------------------------------------------

file=open(f"_dataSetGilBut01\population202202Gender.csv","r",encoding="cp949")
file=csv.reader(file)

for row in file:
    populationfile.append(row)

# print(len(populationfile))

vData = np.array(populationfile)
# print(len(populationfile))
# print(vData.shape)


for x in populationfile:
    if tempSidoNo != (x[0][-11:-9]):
        if x[0][0] == '행':
            pass
        else:
            siDoUK.append(x[0][0:-14])
            siDoNoUK.append(x[0][-11:-9])
            tempSidoNo = x[0][-11:-9]
    elif tempSidoNo == (x[0][-11:-9]):
        pass
    
# print(siDoUK)
# print(siDoNoUK)

for y in range(len(siDoUK)):
    regionMenu.append(siDoUK[y]+":"+siDoNoUK[y][0:2])
    
    
for i in range(len(regionMenu)):
    vmenu=regionMenu[i].split(",")
    menu.append(vmenu)


#----------------------------------------------------------------------------------------

# for idx in range(len(populRegionFileList)):
#     dataSet = open(f'C:\_pythontest01\Analysis\_dataSetGilBut01\population202202.csv','r','cp949')
#     dataSet.close()

# for fileIdx in range(len(populRegionFileList)):
#     dataSet = open(f'_dataSetGilBut01/{populRegionFileList[fileIdx]}','w',newline='',encoding = "cp949")
#     dataSet.close()
    

def regionFileSet() :
    totalRecSu = []          
    tempSiDoNo    = -1
    populRegionFileIdx = 0
    while True:
        for x in range(len(populationfile)) :
            tempRegion = []
            vpop = populationfile[x][0].split()
            if vpop[0] == siDoUK[populRegionFileIdx] :
                if vpop[0] =='행정구역':
                    pass
                else:
                    tempRegion.append(populationfile[x])
                    dataSet = open(f'_dataSetGilBut01/{populRegionFileList[populRegionFileIdx]}','a',newline='',encoding = "cp949")
                    wr = csv.writer(dataSet)
                    wr.writerow(populationfile[x])
        populRegionFileIdx += 1
        if populRegionFileIdx == 17:
            break
        dataSet.close()
                

    for idx in range(len(populRegionFileList)):
        f = open(f'_dataSetGilBut01/{populRegionFileList[idx]}','r',encoding='cp949')
        vf = csv.reader(f)
        b = []
        for a in vf:
            b.append(a)
            c = (b[0][0].split())
        totalRecSu.append(c[0]+':'+str(len(b)))   
    print('-'*50)
    print(totalRecSu)   
    print('-'*50) 

    
        

        
        
    for idx in range(len(populRegionFileList)):
        f = open(f'_dataSetGilBut01/{populRegionFileList[idx]}','r',encoding = "cp949" )
        
                

regionFileSet()
#------regionTitle--------------------------------------------
def regionTitle():
    print("{0:=^91}\n".format("인구 공공데이터 분석 프로젝트 Ver01. "))
    cnt = 0
    for idx in range(17):
        siDoNoUK[idx] = siDoNoUK[idx][:2]
        siDoLen = len(siDoUK[idx]) + (14 - (len(siDoUK[idx])*2))
        print(f"[{siDoUK[idx]:<{siDoLen}}:{siDoNoUK[idx]}]",end="")
        cnt +=1
        
        if cnt%4 == 0:
            print()
    print("\n")

    # print(menu[0:4])
    # print(menu[4:8])
    # print(menu[8:12])
    # print(menu[12:16])
    # print(menu[16:])
    # print('='*98)

#--subMenuTitle---------------------------------------
def subMenuTitle():
    city=""
    userInput=input("\t\t메뉴의 번호를 입력하세요 [Q: 메뉴종료]:")
    if userInput.upper()=="Q":
        exit()
    for idx in range(len(siDoNoUK)):
        print(siDoNoUK[idx])
        if userInput==siDoNoUK[idx]:
            idxChk=idx
            city=siDoUK[idxChk]
            print()
            print(f"\t\t^{siDoUK[idxChk]} 지역이 선택 되었습니다.")
            print()
            break
    else:
        print(f"{userInput} >> 해당 지역 없습니다.")
    return city


#subMenuChk-----------------------------------------------


def subMenuChk(city):
    
    if city in siDoUK:
        #print(siDoUK.index(city))
        idx=siDoUK.index(city)
        
        
        while True:
            print("-"*25, end="")
            print(f"{city}지역 데이터 개수", end="")
            print("-"*25)
            print()
            print("1. 데이터 확인  2. MenuChk  3.MenuChk  4. MenuChk  5.MenuChk 6.MenuChk")
            print("-"*77)
            print()
            userInput=input("서브메뉴 번호를 입력하세요 [Q: 서브메뉴 종료]:")
            if userInput == '1':
                print('데이터 확인')
            elif userInput == '2':
                print('MenuChk 확인')
            elif userInput == '3':
                print('MenuChk 확인')
            elif userInput == '4':
                print('MenuChk 확인')
            elif userInput == '5':
                print('MenuChk 확인')
            elif userInput == '6':
                print('MenuChk 확인')
            elif userInput.upper() == 'Q':
                print('서브메뉴를 종료합니다.')
                break
            else:
                print('해당없음')
                
                
# while True:
#     regionTitle()
#     city = subMenuTitle()
#     subMenuChk(city)
    