import csv
import matplotlib
import pandas as pd
import numpy as np

populationfile = []
siDoGuGunList = []

siDoList = []
soDoNoList = []

siDoNoUK = []   # UK 는 Unique
siDoUK = []

tempSidoNo = -1

file=open(f"_dataSetGilBut01\population202202.csv","r",encoding="cp949")
file=csv.reader(file)

for row in file:
    populationfile.append(row)

# print(len(populationfile))

vData = np.array(populationfile)
# print(len(populationfile))
# print(vData.shape)


for x in populationfile:
    if tempSidoNo != (x[0][-11:-9]):
        if x[0][0] == '행':
            pass
        else:
            siDoUK.append(x[0][0:-14])
            siDoNoUK.append(x[0][-11:-1])
            tempSidoNo = x[0][-11:-9]
    elif tempSidoNo == (x[0][-11:-9]):
        pass
    
# print(siDoUK)
# print(siDoNoUK)

print(len(siDoUK))
for x in range(len(siDoUK)):
    print(siDoUK[x],':',siDoNoUK[x])


