import csv
import matplotlib
import pandas as pd
import numpy as np

populationfile = []

siDoGuGunList = []

siDoList = []
soDoNoList = []

siDoNoUK = []   # UK 는 Unique
siDoUK = []

tempSidoNo = -1

regionMenu = []

menu = []
#-----------------------------------------------------------------------------------------

file=open(f"_dataSetGilBut01\population202202.csv","r",encoding="cp949")
file=csv.reader(file)

for row in file:
    populationfile.append(row)

# print(len(populationfile))

vData = np.array(populationfile)
# print(len(populationfile))
# print(vData.shape)


for x in populationfile:
    if tempSidoNo != (x[0][-11:-9]):
        if x[0][0] == '행':
            pass
        else:
            siDoUK.append(x[0][0:-14])
            siDoNoUK.append(x[0][-11:-9])
            tempSidoNo = x[0][-11:-9]
    elif tempSidoNo == (x[0][-11:-9]):
        pass
    
# print(siDoUK)
# print(siDoNoUK)

for y in range(len(siDoUK)):
    regionMenu.append(siDoUK[y]+":"+siDoNoUK[y][0:2])
    
    
for i in range(len(regionMenu)):
    vmenu=regionMenu[i].split(",")
    menu.append(vmenu)

#------regionTitle--------------------------------------------
def regionTitle():

    print(menu[0:4])
    print(menu[4:8])
    print(menu[8:12])
    print(menu[12:16])
    print(menu[16:])
    print('='*98)

#--subMenuTitle---------------------------------------
def subMenuTitle():
    city=""
    userInput=input("\t\t메뉴의 번호를 입력하세요 [Q: 메뉴종료]:")
    if userInput.upper()=="Q":
        exit()
    for idx in range(len(siDoNoUK)):
        print(siDoNoUK[idx])
        if userInput==siDoNoUK[idx]:
            idxChk=idx
            city=siDoUK[idxChk]
            print()
            print(f"\t\t^{siDoUK[idxChk]} 지역이 선택 되었습니다.")
            print()
            break
    else:
        print(f"{userInput} >> 해당 지역 없습니다.")
    return city


while True:
    regionTitle()
    subMenuTitle()