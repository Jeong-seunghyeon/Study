import csv
import matplotlib
import pandas as pd
import numpy as np

populationfile = []

file=open(f"_dataSetGilBut01\population202202.csv","r",encoding="cp949")
file=csv.reader(file)

for row in file:
    populationfile.append(row)

print(len(populationfile))

vData = np.array(populationfile)
print(len(populationfile))
print(vData.shape)