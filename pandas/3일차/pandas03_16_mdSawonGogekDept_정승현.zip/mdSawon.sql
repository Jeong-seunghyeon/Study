
set pagesize 0
set linesize 0 

set feedback off
set trimspool on

spool C:\_oracleTableBackup\sawonDB_202204.csv

select sabun||','||saname||','||deptno||','||sajob||','||sapay||','||sahire||','||sasex||','||samgr
from sawon;

spool off