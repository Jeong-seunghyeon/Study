
set pagesize 0
set linesize 0 

set feedback off
set trimspool on

spool C:\_oracleTableBackup\GogekDB_202204.csv

select gobun||','||goname||','||gotel||','||gojumin||','||godam
from gogek;

spool off