
set pagesize 0
set linesize 0

set feedback off
set trimspool on

spool C:\_oracleTableBackup\deptDB_202204.csv

select deptno||','||dname||','||loc
from dept;

spool off