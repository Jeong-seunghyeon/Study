import pandas as pd

gapminder = pd.read_csv('./_dataSetPandas/gapminder.tsv',sep='\t')
print(len(gapminder))
print(type(gapminder))
print(gapminder.shape)
print(gapminder.columns)