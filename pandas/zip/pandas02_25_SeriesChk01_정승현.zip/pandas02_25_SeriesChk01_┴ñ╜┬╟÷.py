import pandas as pd


result = pd.Series([1,2,3])
print(result)
print(result.values)
print(result.index)
print(result.dtype)
print(result.shape)
print(result.size)