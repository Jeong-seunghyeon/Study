import pandas as pd

df1 = pd.read_excel('./dataSetPandas/datalabPractice01.xlsx')

print(df1)