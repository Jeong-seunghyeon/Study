CREATE TABLE dept (
    deptno number(3),
    dname varchar2(10),
    loc varchar2(10)
);
