CREATE TABLE gogek (
    gobun number(3),
    goname varchar2(10),
    gotel varchar2(20),
    gojumin varchar2(14),
    godam number(3)
)

