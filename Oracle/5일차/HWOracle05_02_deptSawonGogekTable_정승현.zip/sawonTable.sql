CREATE TABLE sawon (
    sabun number(3),
    saname varchar2(10),
    deptno number(3),
    sajob varchar2(10),
    sapay number(10),
    sahire date,
    sasex varchar2(4),
    samgr number(3)
)
SQL> /
