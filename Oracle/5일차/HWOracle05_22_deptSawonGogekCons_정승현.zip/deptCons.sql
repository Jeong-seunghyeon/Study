create table dept(
deptno number(3) PRIMARY KEY,
dname varchar2(10) UNIQUE,
loc varchar2(10)   
)
/